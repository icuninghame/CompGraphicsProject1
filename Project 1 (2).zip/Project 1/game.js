//Declare variables
var vShaderSource = [
	'attribute vec3 coordinates;',
	'',
	'void main() {',
	'	gl_Position = vec4(coordinates, 1.0);',
	'}'
].join('\n');
var fShaderSource = [
	'precision mediump float;',
	'uniform vec4 fColor;',
	'',
	'void main()',
	'{',
	' gl_FragColor = fColor;',
	'}'
].join('\n');

var score = 0;
var lives = 2;
var bacteriaArray = [];
var particles = [];
var dishRadius = 0.5;
var maxBacteria = 10;
var numBacteria = maxBacteria;

//Main function
function main() {
	//Creates canvas for game
	var canvas = document.getElementById('gameCanvas');
	var gl = canvas.getContext('webgl');

	//Creates canvas for particle effects
	var explosionCanvas = document.getElementById('particles');
	var explosion = explosionCanvas.getContext('2d')

	//Creates a buffer and viewport
	var buffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
	gl.viewport(0,0,canvas.width,canvas.height);

	//Creates shader objects
	var vShader = gl.createShader(gl.VERTEX_SHADER);
	gl.shaderSource(vShader, vShaderSource);
	gl.compileShader(vShader);

	var fShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(fShader, fShaderSource);
	gl.compileShader(fShader);

	//Creates shader program and attaches shader objects to it
	var shaderProgram = gl.createProgram();
	gl.attachShader(shaderProgram, vShader);
	gl.attachShader(shaderProgram, fShader);
	gl.linkProgram(shaderProgram);
	gl.useProgram(shaderProgram);

	//Creates coordinates and color for shader objects
	var location = gl.getAttribLocation(shaderProgram, "coordinates");
	var fColor = gl.getUniformLocation(shaderProgram, "fColor");
	gl.vertexAttribPointer(location, 3, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(location);

	//Allows for determining layer order of shader objects
	gl.enable(gl.DEPTH_TEST);

	//Function distance() finds distance between two points
	function distance(x1, y1, x2, y2) {
		return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
	}

	//Function collision() returns true if two objects are touching
	function collision(x1, y1, radius1, x2, y2, radius2) {
		if(distance(x1, y1, x2, y2) - (radius1 + radius2) <= 0) {
			return true;
		} else {
			return false;
		}
	}

	//Function circle() creates a circle using vertices and triangles 
	function circle(x, y, radius, color) {
		//Declare array
		var vertices = [];

		//Creates points of circle and adds them to stack
		for (let i = 1; i <= 360; i++) {
			var x1 = radius * Math.cos(i) + x;
			var y1 = radius * Math.sin(i) + y;

			var x2 = radius * Math.cos(i + 1) + x;
			var y2 = radius * Math.sin(i + 1) + y;
			

			vertices.push(x);
			vertices.push(y);
			vertices.push(0);

			vertices.push(x1);
			vertices.push(y1);
			vertices.push(0);

			vertices.push(x2);
			vertices.push(y2);
			vertices.push(0);
		}

		//Adds vertices to buffer, gets color, and draws triangles to make the circle
		gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
		gl.uniform4f(fColor, color[0], color[1], color[2], color[3]);
		gl.drawArrays(gl.TRIANGLES, 0, 360 * 6);

	}

	//Function explodeBacteria() removes bacteria circle and adds particle effect
	function explodeBacteria(bacteria){
		//Converts webgl data to canvas date
		var radius = (((bacteria.x + bacteria.radius) + 2/75 + 1) * 300) - (bacteria.x  + 1) * 300;
		//Arbitrary number to reduce number of particles
		var num = 0;

		//for loop to spawn particles
		for(let i = 0; i < radius; i++){
			for(let j = 0; j < radius; j++){
				//Reduces number of particles spawning
				if(num % 100 == 0) {
					//Spawns particle
					particles.push(new Explosion((bacteria.x  + 1) * 300, -1 * (bacteria.y - 1) * 300, 5, bacteria.color));
				}
				num++;
			}
		}
	}

	//50% chance to return the number as a negative
	function negative(num){
		if(Math.random() > 0.5){
			return num = num * (-1);
		} else {
			return num;
		}
	}

	//Bacteria class
	class Bacteria {
		//Bacteria class Constructor
		constructor(num) {
			//Declare variables
			this.num = num;
			this.absorb = [];
		}

		//Function spawn() creates a bacteria circle
		spawn() {
			//Creates random x and y values and angle
			this.xRadius = negative(dishRadius);
			this.yRadius = negative(dishRadius);
			this.angle = Math.random();

			//50% chance of sin or cos being used
			if(Math.random() >= 0.5) {
				this.x = this.xRadius * Math.sin(this.angle);
				this.y = this.yRadius * Math.cos(this.angle);
			} else {
				this.x = this.xRadius * Math.cos(this.angle);
				this.y = this.yRadius * Math.sin(this.angle);
			}

			//For loop to check if any bacteria collide immediately
			for (let i = 0; i < bacteriaArray.length; i++) {
				//Checks if bacteria need to be respawned properly
				if(collision(this.x, this.y, 0.2, bacteriaArray[i].x, bacteriaArray[i].y, bacteriaArray[i].radius)) {
					this.angle = Math.random();
					this.xRadius = negative(dishRadius);
					this.yRadius = negative(dishRadius);
					if(Math.random() >= 0.5) {
						this.x = this.xRadius * Math.sin(this.angle);
						this.y = this.yRadius * Math.cos(this.angle);
					} else {
						this.x = this.xRadius * Math.cos(this.angle);
						this.y = this.yRadius * Math.sin(this.angle);
					}
				}
			}
			//Sets radius, color, and state of bacteria
			this.radius = 0.02;
			this.color = [Math.random(), Math.random(), Math.random(), 1];
			this.alive = true;
		}

		//Function kill() deletes a bacteria circle
		kill(num) {
			//Bacteria disappears
			this.alive = false;
			this.x = 0;
			this.y = 0;
			this.radius = 0;
			numBacteria -= 1;

			//Deletes any bacteria that are absorbed
			for(i in bacteriaArray) {
				if(bacteriaArray[i].absorb.indexOf(this) != -1) {
					bacteriaArray[i].absorb.splice(bacteriaArray[i].absorb.indexOf(this), 1);
				}
			}
		}

		draw() {
			//Checks if bacteria has not been killed
			if(this.alive) {
				//Checks if the bacteria hit the threshold
				if(this.radius > 0.3) {
					lives -= 1;
					this.kill(bacteriaArray.indexOf(this));
				} else {
					//Bacteria grows
					this.radius += 0.0007;

					//For loop that checks if bacteria is colliding with another
					for(i in bacteriaArray) {
						if(this != bacteriaArray[i]){
							if(this.absorb.indexOf(bacteriaArray[i]) == -1 && bacteriaArray[i].absorb.indexOf(this) == -1) {
								if(collision(this.x, this.y, this.radius, bacteriaArray[i].x, bacteriaArray[i].y, bacteriaArray[i].radius)) {
									if(this.num < bacteriaArray[i].num){
										this.absorb.push(bacteriaArray[i]);
									}
								}
						} else {
								for(i in this.absorb) {
									//If fully merged, delete the smaller bacteria
									if(distance(this.x, this.y, this.absorb[i].x, this.absorb[i].y) <= (this.radius - this.absorb[i].radius) || this.absorb[i].radius <= 0.0){
										this.absorb[i].kill(bacteriaArray.indexOf(this.absorb[i]));
									} else {
										//Ratio for changing the size of the bacteria that are merging
										var ratio = merge(this.x, this.y, this.absorb[i].x, this.absorb[i].y);

										//While bigger bacteria absorbs smaller one
										//Size of smaller and bigger one change accordingly
										this.absorb[i].x -= ratio[0]/(2000 * this.absorb[i].radius);
										this.absorb[i].y -= ratio[1]/(2000 * this.absorb[i].radius);
										this.absorb[i].radius -= 0.0025;
										this.radius += 0.025 * this.absorb[i].radius;
									}
								}
							}
						}
					}
				}
				//The bacteria is drawn
				circle(this.x, this.y, this.radius, this.color);
			}
		}
	}

	//Function merge() merges the distance of two points
	function merge(x1, y1, x2, y2) {
		return [(x2 - x1)/distance(x1, y1, x2, y2), (y2 - y1)/distance(x1, y1, x2, y2)];
	}

	//Explosion class
	class Explosion {
		//Explosion class constructor
		constructor(x, y, r, color) {
			//Declare instance variables
			this.x = x;
			this.y = y;
			this.radius = r;
			this.color = color;
			this.speedX = -1 + Math.random() * 5;
			this.speedY = -1 + Math.random() * 5;
			this.time = 40 + Math.random() * 10;
		}

		//Draw function draws the explosion
		draw() {
			//Checks if the explosion time is over or if it disappeared
			if(this.time > 0 && this.radius > 0) {
				//Continues drawing the explosion
				explosion.beginPath();
				explosion.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
				explosion.fill();

				//Reduces time and size of explosion each call
				this.time -= 1;
				this.radius -= 0.15;
				this.x += this.speedX;
				this.y += this.speedY;
			}
		}
	}

	//On mouse click, it calls the function click()
	canvas.onmousedown = function(event, canvas){click(event, gameCanvas);};

	//Function click() determines if mouse clicked on a bacteria
	//If yes, then the bacteria is destroyed and points are earned
	function click(event, canvas) {
		//Gets the coordinates of the mouse click
		let x = event.clientX;
		let y = event.clientY;
		var rect = event.target.getBoundingClientRect();

		//Convert coordinates to webgl coordinates
		x = ((x - rect.left) - canvas.width / 2) / (canvas.width / 2);
		y = (canvas.height / 2 - (y - rect.top)) / (canvas.height / 2);

		//For loop that checks if user clicked on any bacteria
		//If yes, then the bacteria is destroyed and the score is increased
		for(let i in bacteriaArray) {
			if(collision(x, y, 0, bacteriaArray[i].x, bacteriaArray[i].y, bacteriaArray[i].radius)){
				score += Math.round(bacteriaArray[i].radius * 100);
				explodeBacteria(bacteriaArray[i]);
				bacteriaArray[i].kill(i);
			 }
		}
	}

	//Creates bacteria objects and places them in array
	for(var i = 0; i < maxBacteria; i++){
		bacteriaArray.push(new Bacteria(i));
		bacteriaArray[i].spawn();
	}
	//Function tick() runs on every frame update
	function tick() {
		//Updates the user score and lives
		document.getElementById('scoreText').innerHTML=score;
		document.getElementById('livesText').innerHTML=lives;

		//Checks if the game is over
		if(numBacteria > 0 && lives > 0) {
			for (let i in bacteriaArray) {
					bacteriaArray[i].draw();
			}	

			//Draw explosions
			explosion.clearRect(0, 0, canvas.width, canvas.height);
			for(i in particles) {
				particles[i].draw();
			}
		} else if(numBacteria <= 0 && lives > 0) {
			document.getElementById('endText').innerHTML="All the Bacteria was eliminated!"
		} else if(numBacteria >= 0 && lives <= 0) {
			numBacteria = 0;
			document.getElementById('endText').innerHTML="You Died"
		}

		//Creates the dish
		circle(0,0,dishRadius,[0, 0, 1, 1]);

		requestAnimationFrame(tick);
	}
	requestAnimationFrame(tick);
}